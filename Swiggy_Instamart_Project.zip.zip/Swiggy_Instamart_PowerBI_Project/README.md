# Swiggy Instamart Sales & Outlet Performance Analysis

## 📌 Objective
Analyze retail sales performance across regions, categories, and customer segments.

## 🛠 Tools Used
- Power BI
- DAX
- Excel

## 📊 Key KPIs
- Total Revenue
- Total Orders
- Average Order Value (AOV)

## 📈 Features
- Regional sales analysis
- Category-wise performance
- Customer behavior insights
- Interactive filters & slicers

## 📷 Dashboard Preview
(Add screenshot here)

## 💡 Business Insights
- Identified top-performing regions
- Category demand trends analyzed
- Revenue contribution insights